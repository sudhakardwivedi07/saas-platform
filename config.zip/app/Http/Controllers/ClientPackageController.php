<?php

namespace App\Http\Controllers;

use App\Helper\Reply;
use App\Models\ClientPackage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;

class ClientPackageController extends AccountBaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware(['auth']);
        $this->pageTitle = 'My Plans';
    }

    // ── List ─────────────────────────────────────────────────────────────────

    public function index()
    {
        abort_unless(auth()->user()->can('view_plan'), 403);

        $this->plans = ClientPackage::forCompany(auth()->user()->company_id)
            ->orderBy('sort')
            ->orderBy('monthly_price')
            ->get();

        return view('plans.index', $this->data);
    }

    // ── Create form ──────────────────────────────────────────────────────────

    public function create()
    {
        abort_unless(auth()->user()->can('add_plan'), 403);
        return view('plans.create', $this->data);
    }

    // ── Store ────────────────────────────────────────────────────────────────

    public function store(Request $request)
    {
        abort_unless(auth()->user()->can('add_plan'), 403);

        $data = $request->validate([
            'name'             => 'required|string|max:255',
            'description'      => 'nullable|string|max:1000',
            'monthly_price'    => 'required|numeric|min:0',
            'annual_price'     => 'nullable|numeric|min:0',
            'insights_per_month' => 'required|integer|min:1',
            'max_companies'    => 'nullable|integer|min:1',
            'is_free'          => 'boolean',
            'is_recommended'   => 'boolean',
            'is_trial_allowed' => 'boolean',
            'trial_days'       => 'nullable|integer|min:1|max:365',
            'is_active'        => 'boolean',
            'sort'             => 'nullable|integer|min:0',
            'features'         => 'nullable|string',
        ]);

        // Parse comma-separated features into array
        $features = null;
        if (!empty($data['features'])) {
            $features = array_values(array_filter(
                array_map('trim', explode("\n", $data['features']))
            ));
        }

        ClientPackage::create([
            'company_id'              => auth()->user()->company_id,
            'created_by'              => auth()->id(),
            'name'                    => $data['name'],
            'description'             => $data['description'] ?? null,
            'monthly_price'           => $data['monthly_price'],
            'annual_price'            => $data['annual_price'] ?? null,
            'insights_per_month'      => $data['insights_per_month'],
            'max_companies'           => $data['max_companies'] ?? null,
            'features'                => $features,
            'is_free'                 => (bool) ($data['is_free'] ?? false),
            'is_recommended'          => (bool) ($data['is_recommended'] ?? false),
            'is_trial_allowed'        => (bool) ($data['is_trial_allowed'] ?? false),
            'trial_days'              => $data['trial_days'] ?? 0,
            'is_active'               => (bool) ($data['is_active'] ?? true),
            'sort'                    => $data['sort'] ?? 0,
        ]);

        return redirect()->to(route('settings.index') . '#plans')
            ->with('success', "Plan '{$data['name']}' created successfully. It is ready to assign to clients.");
    }

    // ── Edit form ────────────────────────────────────────────────────────────

    public function edit(int $id)
    {
        abort_unless(auth()->user()->can('edit_plan'), 403);

        $this->plan = ClientPackage::forCompany(auth()->user()->company_id)
            ->findOrFail($id);

        return view('plans.edit', $this->data);
    }

    // ── Update ───────────────────────────────────────────────────────────────

    public function update(Request $request, int $id)
    {
        abort_unless(auth()->user()->can('edit_plan'), 403);

        $plan = ClientPackage::forCompany(auth()->user()->company_id)->findOrFail($id);

        $data = $request->validate([
            'name'             => 'required|string|max:255',
            'description'      => 'nullable|string|max:1000',
            'monthly_price'    => 'required|numeric|min:0',
            'annual_price'     => 'nullable|numeric|min:0',
            'insights_per_month' => 'required|integer|min:1',
            'max_companies'    => 'nullable|integer|min:1',
            'is_free'          => 'boolean',
            'is_recommended'   => 'boolean',
            'is_trial_allowed' => 'boolean',
            'trial_days'       => 'nullable|integer|min:1|max:365',
            'is_active'        => 'boolean',
            'sort'             => 'nullable|integer|min:0',
            'features'         => 'nullable|string',
        ]);

        $features = null;
        if (!empty($data['features'])) {
            $features = array_values(array_filter(
                array_map('trim', explode("\n", $data['features']))
            ));
        }

        $plan->update([
            'name'                    => $data['name'],
            'description'             => $data['description'] ?? null,
            'monthly_price'           => $data['monthly_price'],
            'annual_price'            => $data['annual_price'] ?? null,
            'insights_per_month'      => $data['insights_per_month'],
            'max_companies'           => $data['max_companies'] ?? null,
            'features'                => $features,
            'is_free'                 => (bool) ($data['is_free'] ?? false),
            'is_recommended'          => (bool) ($data['is_recommended'] ?? false),
            'is_trial_allowed'        => (bool) ($data['is_trial_allowed'] ?? false),
            'trial_days'              => $data['trial_days'] ?? 0,
            'is_active'               => (bool) ($data['is_active'] ?? true),
            'sort'                    => $data['sort'] ?? 0,
        ]);

        return redirect()->to(route('settings.index') . '#plans')
            ->with('success', "Plan '{$plan->name}' updated successfully.");
    }

    // ── Delete ───────────────────────────────────────────────────────────────

    public function destroy(Request $request, int $id): JsonResponse|RedirectResponse
    {
        abort_unless(auth()->user()->can('delete_plan'), 403);

        $plan = ClientPackage::forCompany(auth()->user()->company_id)->findOrFail($id);
        $name = $plan->name;
        $plan->delete();

        $message = "Plan '{$name}' deleted successfully.";

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json(Reply::success($message));
        }

        $referer = $request->headers->get('Referer', '');
        if ($referer !== '' && str_contains($referer, '/settings')) {
            return redirect()->to(route('settings.index') . '#plans')
                ->with('toast_success', $message);
        }

        return redirect()->route('plans.index')
            ->with('toast_success', $message);
    }

    // ── Toggle active status (AJAX) ───────────────────────────────────────────

    public function toggleStatus(int $id)
    {
        abort_unless(auth()->user()->can('edit_plan'), 403);

        $plan = ClientPackage::forCompany(auth()->user()->company_id)->findOrFail($id);
        $plan->update(['is_active' => !$plan->is_active]);

        return Reply::success('Status updated.');
    }
}
