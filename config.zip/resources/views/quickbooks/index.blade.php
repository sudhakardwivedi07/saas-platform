@extends('layouts.app')
@section('title', 'Connections')
@section('page-title', 'Connections')

@section('content')

@php
    $managedCompanies = $managedCompanies ?? collect();
    $connectedCount    = $connectedCount ?? 0;
    $notConnectedCount = $notConnectedCount ?? 0;
    $connectUrl        = route('quickbooks.connect');
@endphp

{{-- Page Header --}}
<div class="ph">
    <div class="ph-left">
        <h1>Connections</h1>
        <p style="margin:4px 0 0;font-size:13.5px;color:var(--text-3)">Manage accounting tool connections across all your client companies</p>
    </div>
    <div class="ph-right">
        <button onclick="syncAllConnected(this)" id="sync-all-btn" class="btn btn-secondary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
            Sync All
        </button>
    </div>
</div>

{{-- Info Banner --}}
<div class="info-banner" style="margin-bottom:20px">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
    <div class="info-banner-txt">
        <strong>How it works:</strong> For each client company, click <strong>Connect</strong> to link their accounting tool.
        If you already have accountant access, you'll authenticate directly via OAuth. If you need access first, send an invite request
        to your client — they'll grant you accountant access from their QuickBooks settings, then you can connect. Each company requires its own connection.
    </div>
</div>

{{-- Stats Cards --}}
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:24px">
    <div class="acc-card" style="padding:20px 24px">
        <div style="font-size:11px;font-weight:600;color:var(--text-3);letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px">TOTAL COMPANIES</div>
        <div style="font-size:32px;font-weight:700;color:var(--text-1)">{{ $managedCompanies->count() }}</div>
        <div style="font-size:12.5px;color:var(--text-3);margin-top:4px">Across all clients</div>
    </div>
    <div class="acc-card" style="padding:20px 24px;border-color:#10b981">
        <div style="font-size:11px;font-weight:600;color:#10b981;letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px">CONNECTED</div>
        <div style="font-size:32px;font-weight:700;color:#10b981">{{ $connectedCount }}</div>
        <div style="font-size:12.5px;color:var(--text-3);margin-top:4px">Ready for insight generation</div>
    </div>
    <div class="acc-card" style="padding:20px 24px;border-color:#ef4444">
        <div style="font-size:11px;font-weight:600;color:#ef4444;letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px">NOT CONNECTED</div>
        <div style="font-size:32px;font-weight:700;color:#ef4444">{{ $notConnectedCount }}</div>
        <div style="font-size:12.5px;color:var(--text-3);margin-top:4px">Awaiting connection setup</div>
    </div>
</div>

{{-- Table --}}
<div class="tc">
    <div class="tc-head">
        <div class="tc-filters">
            <div class="srch-wrap">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                <input type="text" class="srch-inp" id="qb-search" placeholder="Search companies…" autocomplete="off">
            </div>
            <select class="sel" id="qb-status-filter" autocomplete="off">
                <option value="">All Statuses</option>
                <option value="connected">Connected</option>
                <option value="not connected">Not Connected</option>
                <option value="auth expired">Auth Expired</option>
            </select>
            <button onclick="resetFilters()" class="btn btn-danger">Reset</button>
        </div>
    </div>

    <table id="qb-table" style="width:100%;border-collapse:collapse">
        <thead>
            <tr>
                <th>COMPANY</th>
                <th>CLIENT</th>
                <th>TOOL</th>
                <th>STATUS</th>
                <th>LAST SYNC</th>
                <th style="width:180px">ACTION</th>
            </tr>
        </thead>
        <tbody>
            @forelse($managedCompanies as $company)
            @php
                $conn        = $company->quickbooksConnections->first();
                $primaryUser = $company->users->first();
                if ($conn) {
                    $expired  = $conn->isAccessTokenExpired();
                    $qbStatus = $expired ? 'Auth Expired' : 'Connected';
                    $dotColor = $expired ? 'var(--amber)' : 'var(--green)';
                    $badgeCls = $expired ? 'b-amber' : 'b-green';
                } else {
                    $qbStatus = 'Not Connected';
                    $dotColor = 'var(--red)';
                    $badgeCls = 'b-red';
                }
            @endphp
            <tr>
                <td>
                    <div style="font-weight:500;font-size:13px;color:var(--text-1)">{{ $company->company_name }}</div>
                </td>
                <td>
                    <div style="font-size:13px;color:var(--text-1)">{{ $primaryUser?->name ?? '—' }}</div>
                </td>
                <td>
                    <div style="font-size:13px;color:var(--text-2)">{{ $conn ? 'QuickBooks Online' : '—' }}</div>
                </td>
                <td data-order="{{ $qbStatus }}" data-search="{{ strtolower($qbStatus) }}">
                    <span class="badge {{ $badgeCls }}">
                        <span class="badge-dot" style="background:{{ $dotColor }}"></span>
                        {{ $qbStatus }}
                    </span>
                </td>
                <td style="font-size:12.5px;color:var(--text-2)">
                    {{ $conn?->last_synced_at?->format('M j, Y') ?? '—' }}
                </td>
                <td>
                    @if($conn && !($conn->isAccessTokenExpired()))
                        <div style="display:flex;align-items:center;gap:8px">
                            <button onclick="syncQB({{ $conn->id }}, this)"
                                style="padding:5px 14px;font-size:12.5px;font-weight:500;cursor:pointer;border:1px solid #e5e7eb;background:#fff;color:var(--text-1);border-radius:6px;font-family:inherit;transition:border-color .14s,color .14s"
                                onmouseover="this.style.borderColor='#9ca3af';this.style.color='var(--text-1)'"
                                onmouseout="this.style.borderColor='#e5e7eb';this.style.color='var(--text-1)'">
                                Sync
                            </button>
                            <button onclick="disconnectQB({{ $conn->id }})"
                                style="padding:5px 14px;font-size:12.5px;font-weight:500;cursor:pointer;border:1px solid var(--orange);background:#fff;color:var(--orange);border-radius:6px;font-family:inherit;transition:background .14s,color .14s"
                                onmouseover="this.style.background='var(--orange)';this.style.color='#fff'"
                                onmouseout="this.style.background='#fff';this.style.color='var(--orange)'">
                                Disconnect
                            </button>
                        </div>
                    @elseif($conn)
                        <a href="{{ $connectUrl }}?company_id={{ $company->id }}"
                           style="display:inline-flex;align-items:center;gap:5px;padding:6px 16px;background:var(--orange);color:#fff;border-radius:7px;font-size:13px;font-weight:600;text-decoration:none;transition:background .14s"
                           onmouseover="this.style.background='var(--orange-dark)'" onmouseout="this.style.background='var(--orange)'">
                            Reconnect
                        </a>
                    @else
                        @if($qbConfigured ?? false)
                        <a href="{{ $connectUrl }}?company_id={{ $company->id }}"
                           style="display:inline-flex;align-items:center;gap:5px;padding:6px 16px;background:var(--orange);color:#fff;border-radius:7px;font-size:13px;font-weight:600;text-decoration:none;transition:background .14s"
                           onmouseover="this.style.background='var(--orange-dark)'" onmouseout="this.style.background='var(--orange)'">
                            Connect
                        </a>
                        @else
                        <span style="font-size:12.5px;color:var(--text-3)">Not configured</span>
                        @endif
                    @endif
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6" style="text-align:center;padding:48px 20px;color:var(--text-3)">
                    No client companies found.
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

@endsection

@push('scripts')
<script src="{{ asset(config('assets.jquery')) }}"></script>
<script src="{{ asset(config('assets.datatables_js')) }}"></script>
<script>
const QB_CSRF = document.querySelector('meta[name=csrf-token]').content;

// Connected company IDs for Sync All
const connectedIds = @json(
    $managedCompanies
        ->filter(fn($co) => $co->quickbooksConnections->isNotEmpty() && !$co->quickbooksConnections->first()->isAccessTokenExpired())
        ->map(fn($co) => $co->quickbooksConnections->first()->id)
        ->values()
);

$(document).ready(function () {
    document.getElementById('qb-search').value        = '';
    document.getElementById('qb-status-filter').value = '';

    var table = $('#qb-table').DataTable({
        paging: true, pageLength: 10, lengthChange: true,
        searching: true, ordering: true, info: true,
        dom: '<"dt-tscroll"t><"dt-footer"lip>',
        order: [[0, 'asc']],
        columnDefs: [{ orderable: false, targets: [5] }],
        language: {
            info: 'Showing _START_ to _END_ of _TOTAL_ entries',
            infoEmpty: 'No companies',
            paginate: { previous: 'Previous', next: 'Next' },
            emptyTable: '<div style="text-align:center;padding:48px 20px;color:var(--text-3)">No companies found.</div>',
            lengthMenu: 'Show _MENU_',
        },
    });

    document.getElementById('qb-search').addEventListener('keyup', function () {
        table.search(this.value).draw();
    });
    document.getElementById('qb-status-filter').addEventListener('change', function () {
        const val = this.value;
        table.column(3).search(val ? '^' + val + '$' : '', true, false, true).draw();
    });
});

function resetFilters() {
    document.getElementById('qb-search').value        = '';
    document.getElementById('qb-status-filter').value = '';
    if (window.$.fn && $('#qb-table').DataTable) {
        var t = $('#qb-table').DataTable();
        t.search('').columns().search('').draw();
    }
}

async function syncQB(id, btn) {
    const origText = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = 'Syncing…'; }

    const json = await fetch('{{ route("quickbooks.sync", ":id") }}'.replace(':id', id), {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': QB_CSRF,
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ sync_type: 'customers' }),
    }).then(r => r.json()).catch(() => ({ status: 'error', message: 'Request failed.' }));

    if (btn) { btn.disabled = false; btn.textContent = origText; }

    if (json.status === 'success') {
        // Update Last Sync cell with the date returned from the server
        if (btn && json.last_synced_at) {
            const row = btn.closest('tr');
            if (row) {
                const lastSyncCell = row.cells[4];
                if (lastSyncCell) {
                    lastSyncCell.textContent = json.last_synced_at;
                    lastSyncCell.style.color = 'var(--text-2)';
                }
            }
        }

        if (window.Swal) {
            Swal.fire({
                html: `
                    <div style="display:flex;flex-direction:column;align-items:center;padding:8px 0 4px">
                        <div style="width:64px;height:64px;border-radius:50%;background:#f0fdf4;display:flex;align-items:center;justify-content:center;margin-bottom:18px">
                            <svg viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5" width="30" height="30"><polyline points="20 6 9 17 4 12"/></svg>
                        </div>
                        <div style="font-size:18px;font-weight:700;color:#111827;margin-bottom:10px">Data Synced Successfully</div>
                        <div style="font-size:14px;color:#6b7280;line-height:1.6;text-align:center">
                            Financial data has been refreshed from the accounting tool. Dashboard and insights will reflect the latest data.
                        </div>
                    </div>`,
                showConfirmButton: true,
                confirmButtonText: 'Got it',
                buttonsStyling: false,
                width: 380,
                padding: '32px 28px 28px',
                didOpen: (popup) => {
                    const confirmBtn = popup.querySelector('.swal2-confirm');
                    if (confirmBtn) confirmBtn.style.cssText = 'width:100%;padding:13px 0;background:#f06b25;color:#fff;border:none;border-radius:10px;font-size:15px;font-weight:600;cursor:pointer;font-family:inherit;';
                    const actions = popup.querySelector('.swal2-actions');
                    if (actions) actions.style.cssText = 'width:100%;padding:0;margin-top:24px;display:flex;';
                },
            });
        } else {
            showToast(json.message, 'success');
        }
    } else {
        showToast(json.message, 'error');
    }
}

async function syncAllConnected(btn) {
    if (!connectedIds.length) { showToast('No connected companies to sync.', 'error'); return; }
    btn.disabled = true;
    const orig = btn.innerHTML;
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14" style="animation:qb-spin 1s linear infinite"><polyline points="23 4 23 10 17 10"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10"/></svg> Syncing…';
    for (const id of connectedIds) {
        await fetch('{{ route("quickbooks.sync", ":id") }}'.replace(':id', id), {
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': QB_CSRF, 'Accept': 'application/json', 'Content-Type': 'application/json' },
            body: JSON.stringify({ sync_type: 'customers' }),
        }).catch(() => {});
    }
    showToast('Sync dispatched for ' + connectedIds.length + ' company' + (connectedIds.length !== 1 ? 'ies' : 'y') + '.', 'success');
    btn.disabled = false;
    btn.innerHTML = orig;
}

async function disconnectQB(id) {
    if (!window.Swal) {
        if (!confirm('Disconnect? You will no longer be able to pull financial data until reconnected.')) return;
    } else {
        const confirm = await Swal.fire({
            html: `
                <div style="display:flex;flex-direction:column;align-items:center;padding:8px 0 4px">
                    <div style="width:64px;height:64px;border-radius:50%;background:#fff0f0;display:flex;align-items:center;justify-content:center;margin-bottom:18px">
                        <div style="width:36px;height:36px;border-radius:50%;border:2.5px solid #ef4444;display:flex;align-items:center;justify-content:center">
                            <div style="width:4px;height:14px;background:#ef4444;border-radius:2px;margin-top:2px"></div>
                        </div>
                    </div>
                    <div style="font-size:18px;font-weight:700;color:#111827;margin-bottom:10px">Disconnect Company</div>
                    <div style="font-size:14px;color:#6b7280;line-height:1.6;text-align:center">
                        Are you sure you want to disconnect this company?
                        You will no longer be able to pull financial data
                        or generate insights until reconnected.
                    </div>
                </div>`,
            showCancelButton: true,
            confirmButtonText: 'Confirm',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#f06b25',
            cancelButtonColor: '#fff',
            customClass: {
                confirmButton: 'swal-confirm-btn',
                cancelButton: 'swal-cancel-btn',
            },
            buttonsStyling: true,
            width: 380,
            padding: '32px 28px 28px',
            reverseButtons: false,
        });
        if (!confirm.isConfirmed) return;
    }

    const json = await fetch('{{ route("quickbooks.disconnect", ":id") }}'.replace(':id', id), {
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': QB_CSRF, 'Accept': 'application/json' },
    }).then(r => r.json()).catch(() => ({ status: 'error', message: 'Request failed.' }));

    if (json.status === 'success') {
        if (window.Swal) {
            await Swal.fire({
                html: `
                    <div style="display:flex;flex-direction:column;align-items:center;padding:8px 0 4px">
                        <div style="width:64px;height:64px;border-radius:50%;background:#fff4ee;display:flex;align-items:center;justify-content:center;margin-bottom:18px">
                            <svg viewBox="0 0 24 24" fill="none" stroke="#f06b25" stroke-width="2.5" width="30" height="30"><polyline points="20 6 9 17 4 12"/></svg>
                        </div>
                        <div style="font-size:18px;font-weight:700;color:#111827;margin-bottom:10px">Disconnected</div>
                        <div style="font-size:14px;color:#6b7280;line-height:1.6;text-align:center">
                            The accounting tool connection has been removed.<br>
                            Reconnect to resume data sync and insight generation.
                        </div>
                    </div>`,
                showConfirmButton: true,
                confirmButtonText: 'Got it',
                buttonsStyling: false,
                width: 380,
                padding: '32px 28px 28px',
                didOpen: (popup) => {
                    const btn = popup.querySelector('.swal2-confirm');
                    if (btn) btn.style.cssText = 'width:100%;padding:13px 0;background:#f06b25;color:#fff;border:none;border-radius:10px;font-size:15px;font-weight:600;cursor:pointer;font-family:inherit;';
                    const actions = popup.querySelector('.swal2-actions');
                    if (actions) actions.style.cssText = 'width:100%;padding:0;margin-top:24px;display:flex;';
                },
            });
        }
        location.reload();
    } else {
        showToast(json.message, 'error');
    }
}
</script>
<style>
@keyframes qb-spin { to { transform: rotate(360deg); } }
.swal-got-it-btn  { width:100% !important; border-radius:10px !important; font-size:15px !important; font-weight:600 !important; padding:13px 0 !important; }
.swal-confirm-btn { border-radius:10px !important; font-size:14px !important; font-weight:600 !important; padding:12px 32px !important; }
.swal-cancel-btn  { border-radius:10px !important; font-size:14px !important; font-weight:500 !important; padding:12px 32px !important; border:1px solid #e5e7eb !important; color:#374151 !important; }
.swal-cancel-btn:hover { background:#f9fafb !important; }
.swal2-actions { gap:12px !important; }
</style>
@endpush
